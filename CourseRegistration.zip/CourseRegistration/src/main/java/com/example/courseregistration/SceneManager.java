package com.example.courseregistration;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class SceneManager {

    private static Stage stage;
    private static Scene scene;
    private static Parent root;

    private SceneManager () {}

    public static void switchUserScene(String user) {
        String sceneFile = user + "scene.fxml";
        try {
            root = FXMLLoader.load(SceneManager.class.getResource(sceneFile));
        } catch (IOException e) {
            e.printStackTrace();
        }

        stage = (Stage)((Node)LoginController.event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

        /*switch (user) {
            case "admin":
                AdminScene.initAdminScene(new ActionEvent());
                break;
            case "counselor":
                CounselorScene.initCounsScene(new ActionEvent());
                break;
            case "dean":
                DeanScene.initDeanScene(new ActionEvent());
                break;
            case "professor":
                ProfessorScene.initProfScene(new ActionEvent());
                break;
            case "student":
                new StudentScene().initStudentScene(new ActionEvent());
        }*/
    }

}
