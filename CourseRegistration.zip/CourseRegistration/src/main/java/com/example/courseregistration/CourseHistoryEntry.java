package com.example.courseregistration;

public class CourseHistoryEntry {
    private int SID, grade;
    private String Course_ID;

    public CourseHistoryEntry(int sid, String cid, int grde) {
        SID = sid;
        grade = grde;
        Course_ID = cid;
    }
}
