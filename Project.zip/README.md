Install the program by unzipping Project.zip.
Go to the /project directory and navigate to the folder containing
the Intellij project containing the program. Open that up with
Intellij and run the program!

Use the program by entering in a username/password and then adding/removing
courses, look at previous courses, et cetera. Below are some usernames/passwords
you can use, a student's login.

User:
arete39

Pass:
iamarete

**Make sure you download all the libraries needed for Intellij to work,
especially the MySQL Connector for JDBC included in the zip file**
